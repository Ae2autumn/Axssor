"""Pygame渲染器"""

import pygame
from typing import Optional, List
from ..axn_ass.engine import StyleEngine
from ..axn_ass.stylesheet import StyleSheet
from ..axn_ass.context import StyleContext, StyleElement
from ..axn_ass.layout import LayoutEngine
from .converter import StyleToPygameConverter, RectCommand, TextCommand, BorderCommand, ImageCommand


class PygameRenderer:
    def __init__(self, screen):
        self.screen = screen
        self.style_engine = StyleEngine()
        self.layout_engine = LayoutEngine()
        self.context = StyleContext()
        self.converter = StyleToPygameConverter()
        self.elements = []
        self.width = screen.get_width()
        self.height = screen.get_height()

    def load_styles(self, path):
        stylesheet = StyleSheet()
        stylesheet.load_file(path)
        self.style_engine.load_stylesheet(stylesheet)
        self.style_engine.set_context(self.context)

    def load_styles_string(self, content):
        stylesheet = StyleSheet()
        stylesheet.load_string(content)
        self.style_engine.load_stylesheet(stylesheet)
        self.style_engine.set_context(self.context)

    def add_element(self, tag="div", element_id=None, classes=None, parent=None, text=""):
        element = StyleElement(
            tag=tag,
            element_id=element_id,
            classes=classes or [],
            text_content=text
        )
        if parent:
            parent.add_child(element)
        else:
            self.elements.append(element)
        return element

    def layout(self, width=None, height=None):
        if width:
            self.width = width
        if height:
            self.height = height
        self.style_engine.compute_all()
        for element in self.elements:
            self.layout_engine.layout(element, self.width, self.height, 0, 0)

    def render(self):
        for element in self.elements:
            self._render_element(element)

    def _render_element(self, element):
        if not element.layout_rect:
            return
        styles = element.computed_styles
        if not styles:
            return
        x, y, w, h = element.layout_rect
        rect = pygame.Rect(int(x), int(y), int(w), int(h))
        commands = self.converter.convert(styles, rect, element.text_content)
        for cmd in commands:
            self._execute_command(cmd)
        for child in element.children:
            self._render_element(child)

    def _execute_command(self, cmd):
        if isinstance(cmd, RectCommand):
            if cmd.border_radius > 0:
                pygame.draw.rect(self.screen, cmd.color, cmd.rect, border_radius=cmd.border_radius)
            else:
                pygame.draw.rect(self.screen, cmd.color, cmd.rect)
        elif isinstance(cmd, BorderCommand):
            if cmd.border_radius > 0:
                pygame.draw.rect(self.screen, cmd.border_color, cmd.rect,
                               width=cmd.border_width, border_radius=cmd.border_radius)
            else:
                pygame.draw.rect(self.screen, cmd.border_color, cmd.rect, width=cmd.border_width)
        elif isinstance(cmd, TextCommand):
            text_surface = cmd.font.render(cmd.text, True, cmd.color)
            text_rect = text_surface.get_rect()
            if cmd.alignment == "center":
                text_rect.center = cmd.rect.center
            elif cmd.alignment == "right":
                text_rect.right = cmd.rect.right
                text_rect.centery = cmd.rect.centery
            else:
                text_rect.left = cmd.rect.left
                text_rect.centery = cmd.rect.centery
            self.screen.blit(text_surface, text_rect)
        elif isinstance(cmd, ImageCommand):
            if cmd.alpha < 1.0:
                cmd.image.set_alpha(int(cmd.alpha * 255))
            self.screen.blit(cmd.image, cmd.rect)

    def get_element_at(self, x, y):
        def find_element(element):
            if element.layout_rect:
                ex, ey, ew, eh = element.layout_rect
                if ex <= x <= ex + ew and ey <= y <= ey + eh:
                    for child in reversed(element.children):
                        found = find_element(child)
                        if found:
                            return found
                    return element
            return None
        for element in reversed(self.elements):
            found = find_element(element)
            if found:
                return found
        return None
