"""样式到Pygame绘图命令转换器"""

import pygame
from typing import Dict, List, Any, Tuple, Optional
from dataclasses import dataclass
from ..axn_ass.values import ValueParser


@dataclass
class DrawCommand:
    pass

@dataclass
class RectCommand(DrawCommand):
    rect: pygame.Rect
    color: Tuple[int, int, int]
    border_radius: int = 0

@dataclass
class TextCommand(DrawCommand):
    text: str
    rect: pygame.Rect
    color: Tuple[int, int, int]
    font: pygame.font.Font
    alignment: str = "center"

@dataclass
class BorderCommand(DrawCommand):
    rect: pygame.Rect
    border_width: int
    border_color: Tuple[int, int, int]
    border_radius: int = 0

@dataclass
class ImageCommand(DrawCommand):
    image: pygame.Surface
    rect: pygame.Rect
    alpha: float = 1.0


class StyleToPygameConverter:
    def __init__(self, resource_loader=None):
        from .resources import DefaultResourceLoader
        self.resource_loader = resource_loader or DefaultResourceLoader()

    def convert(self, styles, rect, text=None):
        commands = []
        bg_cmd = self._handle_background(styles, rect)
        if bg_cmd:
            commands.append(bg_cmd)
        border_cmd = self._handle_border(styles, rect)
        if border_cmd:
            commands.append(border_cmd)
        if text:
            text_cmd = self._handle_text(styles, rect, text)
            if text_cmd:
                commands.append(text_cmd)
        return commands

    def _handle_background(self, styles, rect):
        bg_color = styles.get("background-color")
        if not bg_color or bg_color == "transparent":
            return None
        color = self._parse_color(bg_color)
        border_radius = ValueParser.parse_length(styles.get("border-radius", "0")).to_int()
        return RectCommand(rect=rect, color=color, border_radius=border_radius)

    def _handle_border(self, styles, rect):
        border_style = styles.get("border-style", "none")
        if border_style == "none":
            return None
        border_width = ValueParser.parse_length(styles.get("border-width", "0")).to_int()
        if border_width == 0:
            return None
        border_color = styles.get("border-color", "#000")
        border_radius = ValueParser.parse_length(styles.get("border-radius", "0")).to_int()
        return BorderCommand(rect=rect, border_width=border_width,
                           border_color=self._parse_color(border_color),
                           border_radius=border_radius)

    def _handle_text(self, styles, rect, text):
        color_str = styles.get("color", "#000")
        color = self._parse_color(color_str)
        font_size = ValueParser.parse_font_size(styles.get("font-size", "16px"))
        font = self.resource_loader.load_font(None, int(font_size))
        text_align = styles.get("text-align", "left")
        return TextCommand(text=text, rect=rect, color=color,
                         font=font, alignment=text_align)

    def _parse_color(self, value):
        color = ValueParser.parse_color(value)
        if color:
            return color.to_rgb()
        return (0, 0, 0)
