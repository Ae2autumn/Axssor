"""资源加载器"""

import os
import pygame
from typing import Optional, Dict


class ResourceLoader:
    """资源加载器基类"""

    def load_image(self, path: str) -> Optional[pygame.Surface]:
        raise NotImplementedError

    def load_font(self, path: str, size: int) -> Optional[pygame.font.Font]:
        raise NotImplementedError


class DefaultResourceLoader(ResourceLoader):
    """默认资源加载器"""

    def __init__(self, base_path: str = "."):
        self.base_path = base_path
        self._image_cache: Dict[str, pygame.Surface] = {}
        self._font_cache: Dict[tuple, pygame.font.Font] = {}

    def load_image(self, path: str) -> Optional[pygame.Surface]:
        if path.startswith("url("):
            path = path[4:-1].strip('"\')
        if path in self._image_cache:
            return self._image_cache[path]
        full_path = os.path.join(self.base_path, path)
        if not os.path.exists(full_path):
            return None
        try:
            image = pygame.image.load(full_path).convert_alpha()
            self._image_cache[path] = image
            return image
        except:
            return None

    def load_font(self, path: str, size: int) -> Optional[pygame.font.Font]:
        cache_key = (path, size)
        if cache_key in self._font_cache:
            return self._font_cache[cache_key]
        try:
            if path and os.path.exists(path):
                font = pygame.font.Font(path, size)
            else:
                font = pygame.font.SysFont(None, size)
            self._font_cache[cache_key] = font
            return font
        except:
            return pygame.font.SysFont(None, size)

    def clear_cache(self):
        self._image_cache.clear()
        self._font_cache.clear()
