# Axn Style Sheet (ASS)

ASS is a CSS 2.1 subset implementation designed for Axn-Plus visual novel engine.

## Features

- CSS 2.1 compatible syntax
- Selector matching (element, class, ID, attribute, pseudo-class)
- Box model (margin, padding, border)
- Layout engine (block, inline display modes)
- Pygame rendering backend
- Resource caching

## Installation

```bash
pip install -e .
```

## Quick Start

```python
import pygame
from axn_ass_pygame.renderer import PygameRenderer

pygame.init()
screen = pygame.display.set_mode((800, 600))
renderer = PygameRenderer(screen)

# Load styles
renderer.load_styles_string("""
button {
    background-color: #3498db;
    color: white;
    width: 200px;
    height: 50px;
}

button:hover {
    background-color: #2980b9;
}
""")

# Create element
button = renderer.add_element(tag="button", text="Click Me")
button.layout_rect = (300, 275, 200, 50)

# Render
renderer.render()
pygame.display.flip()
```

## Project Structure

```
axn-ass/
├── axn_ass/           # Core style engine
├── axn_ass_pygame/    # Pygame renderer
├── examples/          # Example programs
└── tests/             # Unit tests
```

## License

MIT License
