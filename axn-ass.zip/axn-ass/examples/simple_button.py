#!/usr/bin/env python3
"""简单按钮示例"""

import pygame
import sys
from axn_ass_pygame.renderer import PygameRenderer


def main():
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("ASS Simple Button Example")
    clock = pygame.time.Clock()

    renderer = PygameRenderer(screen)

    styles = """
    button {
        width: 200px;
        height: 50px;
        background-color: #3498db;
        border-radius: 8px;
        color: white;
        font-size: 18px;
        text-align: center;
    }

    button:hover {
        background-color: #2980b9;
    }

    button:active {
        background-color: #1a5276;
    }

    .primary {
        background-color: #e74c3c;
    }

    .primary:hover {
        background-color: #c0392b;
    }
    """

    renderer.load_styles_string(styles)

    button1 = renderer.add_element(tag="button", classes=["primary"], text="Click Me")
    button1.layout_rect = (300, 250, 200, 50)

    button2 = renderer.add_element(tag="button", text="Normal Button")
    button2.layout_rect = (300, 320, 200, 50)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEMOTION:
                pos = pygame.mouse.get_pos()
                for btn in [button1, button2]:
                    x, y, w, h = btn.layout_rect
                    hovered = x <= pos[0] <= x + w and y <= pos[1] <= y + h
                    btn.set_pseudo_class("hover", hovered)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                element = renderer.get_element_at(pos[0], pos[1])
                if element:
                    element.set_pseudo_class("active", True)
                    print(f"Clicked: {element.text_content}")
            elif event.type == pygame.MOUSEBUTTONUP:
                for btn in [button1, button2]:
                    btn.set_pseudo_class("active", False)

        renderer.style_engine.compute_all()

        screen.fill((240, 240, 240))
        renderer.render()
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
