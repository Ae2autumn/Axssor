#!/usr/bin/env python3
"""完整游戏UI示例"""

import pygame
import sys
from axn_ass_pygame.renderer import PygameRenderer


def main():
    pygame.init()
    screen = pygame.display.set_mode((1024, 768))
    pygame.display.set_caption("ASS Game UI Example")
    clock = pygame.time.Clock()

    renderer = PygameRenderer(screen)

    styles = """
    #menu-panel {
        width: 400px;
        height: 500px;
        background-color: #2c3e50;
        border-radius: 12px;
        padding: 20px;
    }

    .title {
        color: #ecf0f1;
        font-size: 32px;
        text-align: center;
        margin-bottom: 30px;
    }

    .menu-btn {
        width: 100%;
        height: 50px;
        background-color: #34495e;
        color: #ecf0f1;
        font-size: 20px;
        text-align: center;
        margin-bottom: 10px;
        border-radius: 6px;
    }

    .menu-btn:hover {
        background-color: #3498db;
    }

    .menu-btn:active {
        background-color: #2980b9;
    }
    """

    renderer.load_styles_string(styles)

    panel = renderer.add_element(tag="div", element_id="menu-panel")
    panel.layout_rect = (312, 134, 400, 500)

    title = renderer.add_element(tag="h1", classes=["title"], parent=panel, text="Game Menu")
    title.layout_rect = (332, 154, 360, 50)

    buttons = ["Start Game", "Load Game", "Settings", "Exit"]
    y_offset = 234
    for btn_text in buttons:
        btn = renderer.add_element(tag="button", classes=["menu-btn"],
                                  parent=panel, text=btn_text)
        btn.layout_rect = (332, y_offset, 360, 50)
        y_offset += 60

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEMOTION:
                pos = pygame.mouse.get_pos()
                element = renderer.get_element_at(pos[0], pos[1])
                for el in renderer.context.all_elements:
                    el.set_pseudo_class("hover", el == element)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()
                element = renderer.get_element_at(pos[0], pos[1])
                if element and element.tag == "button":
                    element.set_pseudo_class("active", True)
                    print(f"Clicked: {element.text_content}")
            elif event.type == pygame.MOUSEBUTTONUP:
                for el in renderer.context.all_elements:
                    el.set_pseudo_class("active", False)

        renderer.style_engine.compute_all()

        screen.fill((26, 26, 26))
        renderer.render()
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    main()
