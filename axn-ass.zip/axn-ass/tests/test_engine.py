#!/usr/bin/env python3
"""样式引擎单元测试"""

import unittest
from axn_ass.values import ValueParser, Color, Length
from axn_ass.stylesheet import StyleSheet
from axn_ass.context import StyleElement, StyleContext
from axn_ass.engine import StyleEngine
from axn_ass.selector import SelectorParser


class TestValueParser(unittest.TestCase):
    def test_parse_color_hex(self):
        color = ValueParser.parse_color("#ff0000")
        self.assertIsNotNone(color)
        self.assertEqual(color.to_rgb(), (255, 0, 0))

    def test_parse_color_rgb(self):
        color = ValueParser.parse_color("rgb(255, 128, 0)")
        self.assertIsNotNone(color)
        self.assertEqual(color.to_rgb(), (255, 128, 0))

    def test_parse_color_name(self):
        color = ValueParser.parse_color("red")
        self.assertIsNotNone(color)
        self.assertEqual(color.to_rgb(), (255, 0, 0))

    def test_parse_length_px(self):
        length = ValueParser.parse_length("100px")
        self.assertEqual(length.to_px(), 100)

    def test_parse_length_em(self):
        length = ValueParser.parse_length("2em")
        self.assertEqual(length.to_px(16), 32)


class TestStyleSheet(unittest.TestCase):
    def test_parse_simple_rule(self):
        css = "button { color: red; }"
        sheet = StyleSheet()
        sheet.load_string(css)
        self.assertEqual(len(sheet.rules), 1)
        self.assertEqual(sheet.rules[0].selector, "button")
        self.assertEqual(sheet.rules[0].declarations["color"], "red")

    def test_parse_multiple_rules(self):
        css = "button { color: red; } div { width: 100px; }"
        sheet = StyleSheet()
        sheet.load_string(css)
        self.assertEqual(len(sheet.rules), 2)


class TestStyleEngine(unittest.TestCase):
    def test_inheritance(self):
        css = "div { color: blue; } span { }"
        sheet = StyleSheet()
        sheet.load_string(css)

        parent = StyleElement(tag="div")
        child = StyleElement(tag="span")
        parent.add_child(child)

        engine = StyleEngine()
        engine.load_stylesheet(sheet)
        styles = engine.calculate_styles(child)
        self.assertEqual(styles.get("color"), "blue")

    def test_specificity(self):
        css = "button { color: red; } #btn { color: blue; }"
        sheet = StyleSheet()
        sheet.load_string(css)

        element = StyleElement(tag="button", element_id="btn")
        engine = StyleEngine()
        engine.load_stylesheet(sheet)
        styles = engine.calculate_styles(element)
        self.assertEqual(styles.get("color"), "blue")


class TestSelector(unittest.TestCase):
    def test_element_selector(self):
        element = StyleElement(tag="button")
        self.assertTrue(SelectorParser.matches("button", element))
        self.assertFalse(SelectorParser.matches("div", element))

    def test_class_selector(self):
        element = StyleElement(tag="div", classes=["primary"])
        self.assertTrue(SelectorParser.matches(".primary", element))
        self.assertFalse(SelectorParser.matches(".secondary", element))

    def test_id_selector(self):
        element = StyleElement(tag="div", element_id="main")
        self.assertTrue(SelectorParser.matches("#main", element))
        self.assertFalse(SelectorParser.matches("#other", element))


if __name__ == "__main__":
    unittest.main()
