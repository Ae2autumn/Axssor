"""值解析模块 - 颜色、长度、百分比等"""

import re
from typing import Tuple, Optional, Union, List
from dataclasses import dataclass


@dataclass
class Color:
    """RGBA 颜色"""
    r: int
    g: int
    b: int
    a: int = 255

    def to_rgb(self) -> Tuple[int, int, int]:
        return (self.r, self.g, self.b)

    def to_rgba(self) -> Tuple[int, int, int, int]:
        return (self.r, self.g, self.b, self.a)

    def __str__(self):
        if self.a == 255:
            return f"#{self.r:02x}{self.g:02x}{self.b:02x}"
        return f"rgba({self.r}, {self.g}, {self.b}, {self.a / 255:.2f})"


@dataclass
class Length:
    """长度值"""
    value: float
    unit: str  # px, em, %, pt, 或 空字符串表示数字

    def to_px(self, context: float = 16.0) -> float:
        """转换为像素"""
        if self.unit == "px" or self.unit == "":
            return self.value
        elif self.unit == "em":
            return self.value * context
        elif self.unit == "%":
            return self.value / 100.0 * context
        elif self.unit == "pt":
            return self.value * 96 / 72
        else:
            return self.value

    def to_int(self, context: float = 16.0) -> int:
        return int(self.to_px(context))


class ValueParser:
    """值解析器"""

    # 基础颜色名
    COLOR_NAMES = {
        "black": (0, 0, 0),
        "white": (255, 255, 255),
        "red": (255, 0, 0),
        "green": (0, 128, 0),
        "blue": (0, 0, 255),
        "yellow": (255, 255, 0),
        "cyan": (0, 255, 255),
        "magenta": (255, 0, 255),
        "gray": (128, 128, 128),
        "grey": (128, 128, 128),
        "silver": (192, 192, 192),
        "maroon": (128, 0, 0),
        "olive": (128, 128, 0),
        "purple": (128, 0, 128),
        "teal": (0, 128, 128),
        "navy": (0, 0, 128),
        "lime": (0, 255, 0),
        "aqua": (0, 255, 255),
        "fuchsia": (255, 0, 255),
        "orange": (255, 165, 0),
        "transparent": (0, 0, 0, 0),
    }

    # 绝对字体大小
    ABSOLUTE_FONT_SIZES = {
        "xx-small": 9,
        "x-small": 10,
        "small": 13,
        "medium": 16,
        "large": 18,
        "x-large": 24,
        "xx-large": 32,
    }

    @classmethod
    def parse_color(cls, value: str) -> Optional[Color]:
        """解析颜色值"""
        if not value:
            return None

        value = value.strip().lower()

        # 关键字
        if value in cls.COLOR_NAMES:
            rgb = cls.COLOR_NAMES[value]
            if len(rgb) == 4:
                return Color(*rgb)
            return Color(*rgb, 255)

        # #RRGGBB 或 #RGB
        if value.startswith("#"):
            if len(value) == 7:
                return Color(
                    int(value[1:3], 16),
                    int(value[3:5], 16),
                    int(value[5:7], 16)
                )
            elif len(value) == 4:
                return Color(
                    int(value[1]*2, 16),
                    int(value[2]*2, 16),
                    int(value[3]*2, 16)
                )

        # rgb(r, g, b)
        rgb_match = re.match(r"rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)", value)
        if rgb_match:
            return Color(
                int(rgb_match.group(1)),
                int(rgb_match.group(2)),
                int(rgb_match.group(3))
            )

        # rgba(r, g, b, a)
        rgba_match = re.match(r"rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*([\d.]+)\s*\)", value)
        if rgba_match:
            return Color(
                int(rgba_match.group(1)),
                int(rgba_match.group(2)),
                int(rgba_match.group(3)),
                int(float(rgba_match.group(4)) * 255)
            )

        return None

    @classmethod
    def parse_length(cls, value: str, default_unit: str = "px") -> Length:
        """解析长度值"""
        if not value:
            return Length(0, default_unit)

        if isinstance(value, (int, float)):
            return Length(float(value), default_unit)

        value = value.strip().lower()

        # 纯数字
        if value.isdigit() or (value.startswith("-") and value[1:].isdigit()):
            return Length(float(value), default_unit)

        # 数字 + 单位
        match = re.match(r"^(-?\d+(?:\.\d+)?)(px|em|%|pt|cm|mm|in)?$", value)
        if match:
            num = float(match.group(1))
            unit = match.group(2) or default_unit
            return Length(num, unit)

        return Length(0, default_unit)

    @classmethod
    def parse_box(cls, value: str, default: int = 0) -> Tuple[int, int, int, int]:
        """解析 margin/padding 的 1-4 个值"""
        if not value:
            return (default, default, default, default)

        parts = value.strip().split()

        if len(parts) == 1:
            v = cls.parse_length(parts[0]).to_int()
            return (v, v, v, v)
        elif len(parts) == 2:
            v1 = cls.parse_length(parts[0]).to_int()
            v2 = cls.parse_length(parts[1]).to_int()
            return (v1, v2, v1, v2)
        elif len(parts) == 3:
            v1 = cls.parse_length(parts[0]).to_int()
            v2 = cls.parse_length(parts[1]).to_int()
            v3 = cls.parse_length(parts[2]).to_int()
            return (v1, v2, v3, v2)
        else:
            return (
                cls.parse_length(parts[0]).to_int(),
                cls.parse_length(parts[1]).to_int(),
                cls.parse_length(parts[2]).to_int(),
                cls.parse_length(parts[3]).to_int()
            )

    @classmethod
    def parse_font_size(cls, value: str, parent_size: float = 16.0) -> float:
        """解析字体大小"""
        if not value:
            return parent_size

        value = value.strip().lower()

        # 绝对大小
        if value in cls.ABSOLUTE_FONT_SIZES:
            return cls.ABSOLUTE_FONT_SIZES[value]

        # 相对大小
        if value == "larger":
            return parent_size * 1.2
        if value == "smaller":
            return parent_size * 0.8

        # 百分比
        if value.endswith("%"):
            return parent_size * float(value[:-1]) / 100.0

        # 长度值
        length = cls.parse_length(value)
        return length.to_px(parent_size)
