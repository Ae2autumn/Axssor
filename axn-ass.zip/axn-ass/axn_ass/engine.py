"""样式计算引擎"""

from typing import Dict, Any, Optional, List
from .stylesheet import StyleSheet, StyleRule
from .context import StyleContext, StyleElement
from .values import ValueParser


class StyleEngine:
    """样式计算引擎 - 执行级联、继承和特异性计算"""

    # 可继承的属性列表
    INHERITED_PROPERTIES = {
        "color", "font-family", "font-size", "font-weight", "font-style",
        "font-variant", "letter-spacing", "word-spacing", "line-height",
        "text-align", "text-indent", "text-transform", "white-space",
        "visibility", "cursor", "quotes", "list-style-type",
        "list-style-image", "list-style-position",
    }

    # 默认值
    DEFAULT_VALUES = {
        "display": "inline",
        "position": "static",
        "float": "none",
        "clear": "none",
        "visibility": "visible",
        "overflow": "visible",
        "width": "auto",
        "height": "auto",
        "margin": "0",
        "padding": "0",
        "border-width": "0",
        "border-style": "none",
        "border-color": "#000",
        "background-color": "transparent",
        "background-image": "none",
        "color": "#000",
        "font-size": "16px",
        "font-family": "sans-serif",
        "font-weight": "normal",
        "font-style": "normal",
        "text-align": "left",
        "text-decoration": "none",
        "line-height": "normal",
        "z-index": "auto",
        "opacity": "1",
        "border-radius": "0",
    }

    def __init__(self):
        self.stylesheet = None
        self.context = None
        self._computed_cache = {}

    def load_stylesheet(self, stylesheet) -> None:
        """加载样式表"""
        self.stylesheet = stylesheet
        self._computed_cache.clear()

    def set_context(self, context) -> None:
        """设置DOM上下文"""
        self.context = context
        self._computed_cache.clear()

    def calculate_styles(self, element, parent_styles=None):
        """计算元素的最终样式"""
        if not self.stylesheet:
            return {}

        # 检查缓存
        element_id = id(element)
        if element_id in self._computed_cache:
            return self._computed_cache[element_id]

        # 获取匹配的规则
        matching_rules = self.stylesheet.get_rules_for_element(element)

        # 按特异性排序
        matching_rules.sort(key=lambda r: r.specificity)

        # 合并样式
        computed = {}

        # 1. 应用默认值
        computed.update(self.DEFAULT_VALUES)

        # 2. 应用继承值
        if parent_styles:
            for prop in self.INHERITED_PROPERTIES:
                if prop in parent_styles:
                    computed[prop] = parent_styles[prop]

        # 3. 应用匹配规则的样式
        for rule in matching_rules:
            computed.update(rule.declarations)

        # 4. 处理伪类
        for pseudo_name, pseudo_active in element.pseudo_classes.items():
            if pseudo_active:
                pseudo_rules = self._get_pseudo_rules(element, pseudo_name)
                computed.update(pseudo_rules)

        # 存储并返回
        element.computed_styles = computed
        self._computed_cache[element_id] = computed
        return computed

    def _get_pseudo_rules(self, element, pseudo_name):
        """获取伪类规则"""
        result = {}
        if not self.stylesheet:
            return result

        # 查找包含该伪类的规则
        for rule in self.stylesheet.rules:
            if ":" + pseudo_name in rule.selector:
                from .selector import SelectorParser
                base_selector = rule.selector.split(":" + pseudo_name)[0].strip()
                if not base_selector or SelectorParser.matches(base_selector, element):
                    result.update(rule.declarations)

        return result

    def invalidate_cache(self, element=None):
        """使缓存失效"""
        if element is None:
            self._computed_cache.clear()
        else:
            self._computed_cache.pop(id(element), None)

    def compute_all(self):
        """计算所有元素的样式"""
        if not self.context or not self.context.root:
            return
        self._compute_recursive(self.context.root, None)

    def _compute_recursive(self, element, parent_styles):
        """递归计算样式"""
        styles = self.calculate_styles(element, parent_styles)
        for child in element.children:
            self._compute_recursive(child, styles)
