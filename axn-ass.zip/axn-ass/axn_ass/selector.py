"""选择器匹配模块"""

import re
from typing import List, Tuple, Optional, Dict, Any
from dataclasses import dataclass


@dataclass
class Selector:
    """CSS选择器"""
    raw: str
    specificity: Tuple[int, int, int] = (0, 0, 0)  # (id, class, element)

    def matches(self, element) -> bool:
        """检查选择器是否匹配元素"""
        return SelectorParser.matches(self.raw, element)


class SelectorParser:
    """选择器解析器"""

    @staticmethod
    def parse(selector_str: str) -> Selector:
        """解析选择器字符串"""
        specificity = SelectorParser._calculate_specificity(selector_str)
        return Selector(raw=selector_str.strip(), specificity=specificity)

    @staticmethod
    def _calculate_specificity(selector: str) -> Tuple[int, int, int]:
        """计算选择器特异性 (id, class, element)"""
        id_count = selector.count("#")
        class_count = selector.count(".") + selector.count("[")
        element_count = len(re.findall(r"^[a-zA-Z]+", selector.strip()))
        return (id_count, class_count, element_count)

    @staticmethod
    def matches(selector: str, element) -> bool:
        """检查选择器是否匹配元素"""
        if not selector or not element:
            return False

        selector = selector.strip()

        # 处理多选择器 (逗号分隔)
        if "," in selector:
            parts = [s.strip() for s in selector.split(",")]
            return any(SelectorParser.matches(part, element) for part in parts)

        # 处理后代选择器 (空格分隔)
        if " " in selector and not any(c in selector for c in ">+~"):
            parts = selector.split()
            return SelectorParser._matches_descendant(parts, element)

        # 处理子元素选择器
        if ">" in selector:
            parent_sel, child_sel = selector.split(">", 1)
            parent = element.parent
            if not parent:
                return False
            return (SelectorParser.matches(parent_sel.strip(), parent) and
                    SelectorParser.matches(child_sel.strip(), element))

        # 处理相邻兄弟选择器
        if "+" in selector:
            prev_sel, curr_sel = selector.split("+", 1)
            prev_sibling = element.get_previous_sibling()
            if not prev_sibling:
                return False
            return (SelectorParser.matches(prev_sel.strip(), prev_sibling) and
                    SelectorParser.matches(curr_sel.strip(), element))

        # 处理通用兄弟选择器
        if "~" in selector:
            sibling_sel, curr_sel = selector.split("~", 1)
            siblings = element.get_previous_siblings()
            return (any(SelectorParser.matches(sibling_sel.strip(), s) for s in siblings) and
                    SelectorParser.matches(curr_sel.strip(), element))

        # 处理伪类
        if ":" in selector:
            base, pseudo = selector.split(":", 1)
            base = base.strip()
            pseudo = pseudo.strip()
            if base and not SelectorParser._matches_simple(base, element):
                return False
            return SelectorParser._matches_pseudo(pseudo, element)

        # 简单选择器
        return SelectorParser._matches_simple(selector, element)

    @staticmethod
    def _matches_simple(selector: str, element) -> bool:
        """匹配简单选择器"""
        selector = selector.strip()

        # 通配符
        if selector == "*":
            return True

        # ID选择器
        if selector.startswith("#"):
            return element.element_id == selector[1:]

        # 类选择器
        if selector.startswith("."):
            return selector[1:] in element.classes

        # 属性选择器
        if selector.startswith("[") and selector.endswith("]"):
            return SelectorParser._matches_attribute(selector[1:-1], element)

        # 元素选择器
        return element.tag == selector

    @staticmethod
    def _matches_attribute(attr_spec: str, element) -> bool:
        """匹配属性选择器"""
        # 存在属性 [attr]
        if "=" not in attr_spec:
            return attr_spec.strip() in element.attributes

        # 精确匹配 [attr=value]
        if "~=" not in attr_spec and "|=" not in attr_spec:
            attr, val = attr_spec.split("=", 1)
            attr = attr.strip()
            val = val.strip().strip('"\')
            return element.attributes.get(attr) == val

        # 包含词 [attr~=value]
        if "~=" in attr_spec:
            attr, val = attr_spec.split("~=", 1)
            attr = attr.strip()
            val = val.strip().strip('"\')
            attr_val = element.attributes.get(attr, "")
            return val in attr_val.split()

        return False

    @staticmethod
    def _matches_pseudo(pseudo: str, element) -> bool:
        """匹配伪类"""
        pseudo = pseudo.strip().lower()

        if pseudo == "hover":
            return element.pseudo_classes.get("hover", False)
        elif pseudo == "active":
            return element.pseudo_classes.get("active", False)
        elif pseudo == "focus":
            return element.pseudo_classes.get("focus", False)
        elif pseudo == "first-child":
            return element.is_first_child()
        elif pseudo == "last-child":
            return element.is_last_child()
        elif pseudo == "only-child":
            return element.is_only_child()
        elif pseudo == "empty":
            return element.is_empty()
        elif pseudo == "root":
            return element.parent is None

        return False

    @staticmethod
    def _matches_descendant(parts: List[str], element) -> bool:
        """匹配后代选择器"""
        if not parts:
            return False

        # 最后一个部分必须匹配当前元素
        if not SelectorParser._matches_simple(parts[-1], element):
            return False

        # 递归检查祖先
        current = element.parent
        for part in reversed(parts[:-1]):
            while current:
                if SelectorParser._matches_simple(part, current):
                    break
                current = current.parent
            if not current:
                return False
            current = current.parent

        return True
