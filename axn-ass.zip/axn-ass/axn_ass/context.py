"""DOM上下文管理模块"""

from typing import List, Dict, Optional, Any
from dataclasses import dataclass, field


@dataclass
class StyleElement:
    """样式元素 - 模拟DOM元素"""
    tag: str = "div"
    element_id: Optional[str] = None
    classes: List[str] = field(default_factory=list)
    attributes: Dict[str, str] = field(default_factory=dict)
    pseudo_classes: Dict[str, bool] = field(default_factory=dict)
    parent: Optional["StyleElement"] = None
    children: List["StyleElement"] = field(default_factory=list)
    text_content: str = ""
    computed_styles: Dict[str, Any] = field(default_factory=dict)
    layout_rect: Optional[tuple] = None  # (x, y, width, height)

    def __post_init__(self):
        """初始化后处理"""
        if self.classes is None:
            self.classes = []
        if self.attributes is None:
            self.attributes = {}
        if self.pseudo_classes is None:
            self.pseudo_classes = {}
        if self.children is None:
            self.children = []
        if self.computed_styles is None:
            self.computed_styles = {}

    def add_child(self, child: "StyleElement") -> "StyleElement":
        """添加子元素"""
        child.parent = self
        self.children.append(child)
        return child

    def remove_child(self, child: "StyleElement") -> None:
        """移除子元素"""
        if child in self.children:
            self.children.remove(child)
            child.parent = None

    def set_pseudo_class(self, name: str, value: bool) -> None:
        """设置伪类状态"""
        self.pseudo_classes[name] = value

    def get_previous_sibling(self) -> Optional["StyleElement"]:
        """获取前一个兄弟元素"""
        if not self.parent:
            return None
        siblings = self.parent.children
        try:
            idx = siblings.index(self)
            if idx > 0:
                return siblings[idx - 1]
        except ValueError:
            pass
        return None

    def get_previous_siblings(self) -> List["StyleElement"]:
        """获取所有前面的兄弟元素"""
        if not self.parent:
            return []
        siblings = self.parent.children
        try:
            idx = siblings.index(self)
            return siblings[:idx]
        except ValueError:
            return []

    def is_first_child(self) -> bool:
        """是否是第一个子元素"""
        if not self.parent:
            return False
        return self.parent.children[0] == self if self.parent.children else False

    def is_last_child(self) -> bool:
        """是否是最后一个子元素"""
        if not self.parent:
            return False
        return self.parent.children[-1] == self if self.parent.children else False

    def is_only_child(self) -> bool:
        """是否是唯一的子元素"""
        if not self.parent:
            return False
        return len(self.parent.children) == 1

    def is_empty(self) -> bool:
        """是否为空元素"""
        return not self.children and not self.text_content.strip()

    def get_full_selector(self) -> str:
        """获取完整选择器路径"""
        parts = []
        current = self
        while current:
            part = current.tag
            if current.element_id:
                part += f"#{current.element_id}"
            for cls in current.classes:
                part += f".{cls}"
            parts.insert(0, part)
            current = current.parent
        return " ".join(parts)


class StyleContext:
    """样式上下文 - 管理元素树"""

    def __init__(self):
        self.root: Optional[StyleElement] = None
        self.elements_by_id: Dict[str, StyleElement] = {}
        self.all_elements: List[StyleElement] = []

    def set_root(self, root: StyleElement) -> None:
        """设置根元素"""
        self.root = root
        self._rebuild_index()

    def _rebuild_index(self) -> None:
        """重建元素索引"""
        self.elements_by_id.clear()
        self.all_elements.clear()
        if self.root:
            self._index_element(self.root)

    def _index_element(self, element: StyleElement) -> None:
        """索引元素"""
        self.all_elements.append(element)
        if element.element_id:
            self.elements_by_id[element.element_id] = element
        for child in element.children:
            self._index_element(child)

    def get_element_by_id(self, element_id: str) -> Optional[StyleElement]:
        """通过ID获取元素"""
        return self.elements_by_id.get(element_id)

    def query_selector(self, selector: str) -> Optional[StyleElement]:
        """查询单个元素"""
        from .selector import SelectorParser
        for element in self.all_elements:
            if SelectorParser.matches(selector, element):
                return element
        return None

    def query_selector_all(self, selector: str) -> List[StyleElement]:
        """查询所有匹配元素"""
        from .selector import SelectorParser
        return [e for e in self.all_elements if SelectorParser.matches(selector, e)]
