"""样式表解析模块"""

import re
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass, field


@dataclass
class StyleRule:
    """样式规则"""
    selector: str
    declarations: Dict[str, str] = field(default_factory=dict)
    specificity: Tuple[int, int, int] = (0, 0, 0)
    line_number: int = 0


class StyleSheet:
    """样式表解析器"""

    def __init__(self):
        self.rules: List[StyleRule] = []
        self.source_file: Optional[str] = None

    def load_string(self, content: str) -> None:
        """从字符串加载样式"""
        self._parse(content)

    def load_file(self, path: str) -> None:
        """从文件加载样式"""
        self.source_file = path
        with open(path, "r", encoding="utf-8") as f:
            self._parse(f.read())

    def _parse(self, content: str) -> None:
        """解析CSS内容"""
        # 移除注释
        content = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)

        # 解析规则
        pattern = r"([^{]+)\{([^}]+)\}"
        matches = re.findall(pattern, content)

        for i, (selector, declarations) in enumerate(matches):
            selector = selector.strip()
            if not selector:
                continue

            # 解析声明
            decls = self._parse_declarations(declarations)

            # 计算特异性
            specificity = self._calculate_specificity(selector)

            rule = StyleRule(
                selector=selector,
                declarations=decls,
                specificity=specificity,
                line_number=i + 1
            )
            self.rules.append(rule)

        # 按特异性排序（低特异性在前，高特异性在后）
        self.rules.sort(key=lambda r: r.specificity)

    def _parse_declarations(self, declarations: str) -> Dict[str, str]:
        """解析声明块"""
        result = {}
        # 按分号分割，但注意字符串中的分号
        decls = re.split(r";(?![^"]*")", declarations)

        for decl in decls:
            decl = decl.strip()
            if not decl:
                continue
            if ":" in decl:
                prop, val = decl.split(":", 1)
                result[prop.strip().lower()] = val.strip()

        return result

    def _calculate_specificity(self, selector: str) -> Tuple[int, int, int]:
        """计算选择器特异性"""
        # 分别处理逗号分隔的选择器
        parts = selector.split(",")
        max_spec = (0, 0, 0)

        for part in parts:
            part = part.strip()
            # ID选择器
            id_count = len(re.findall(r"#[a-zA-Z_][a-zA-Z0-9_-]*", part))
            # 类选择器和属性选择器
            class_count = len(re.findall(r"\.[a-zA-Z_][a-zA-Z0-9_-]*", part))
            class_count += len(re.findall(r"\[", part))
            # 伪类
            class_count += len(re.findall(r":(?![a-z]+\()", part))
            # 元素选择器
            element_count = len(re.findall(r"(^|\s|>\+|~)([a-zA-Z_][a-zA-Z0-9_-]*)", part))

            spec = (id_count, class_count, element_count)
            if spec > max_spec:
                max_spec = spec

        return max_spec

    def get_rules_for_element(self, element) -> List[StyleRule]:
        """获取匹配元素的所有规则"""
        from .selector import SelectorParser
        matching_rules = []
        for rule in self.rules:
            if SelectorParser.matches(rule.selector, element):
                matching_rules.append(rule)
        return matching_rules
