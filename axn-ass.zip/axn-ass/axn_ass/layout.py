"""布局引擎"""

from typing import Dict, Any, Optional, Tuple
from .context import StyleElement
from .values import ValueParser


class LayoutEngine:
    """布局引擎 - 基于CSS盒模型进行几何计算"""

    def __init__(self):
        self.container_width = 800
        self.container_height = 600
        self.default_font_size = 16

    def layout(self, element: StyleElement, available_width: float, available_height: float,
               x: float = 0, y: float = 0) -> Tuple[float, float]:
        """
        计算元素布局
        返回: (实际宽度, 实际高度)
        """
        styles = element.computed_styles

        # 获取盒模型值
        margin = self._parse_box(styles.get("margin", "0"))
        padding = self._parse_box(styles.get("padding", "0"))
        border_width = self._parse_border_width(styles.get("border-width", "0"))

        # 计算内容区域尺寸
        content_width = self._calculate_width(styles, available_width, margin, padding, border_width)
        content_height = self._calculate_height(styles, available_height)

        # 设置元素位置
        element.layout_rect = (
            x + margin[3] + border_width[3],  # left
            y + margin[0] + border_width[0],  # top
            content_width,
            content_height
        )

        # 布局子元素
        display = styles.get("display", "block")
        if display == "block":
            self._layout_block_children(element, content_width, content_height)
        elif display == "inline":
            self._layout_inline_children(element, content_width, content_height)

        # 计算实际占用空间
        total_width = margin[3] + border_width[3] + padding[3] + content_width + padding[1] + border_width[1] + margin[1]
        total_height = margin[0] + border_width[0] + padding[0] + content_height + padding[2] + border_width[2] + margin[2]

        return (total_width, total_height)

    def _parse_box(self, value: str) -> Tuple[int, int, int, int]:
        """解析margin/padding值"""
        return ValueParser.parse_box(value, 0)

    def _parse_border_width(self, value: str) -> Tuple[int, int, int, int]:
        """解析边框宽度"""
        if value in ["thin", "medium", "thick"]:
            width = {"thin": 1, "medium": 3, "thick": 5}.get(value, 0)
            return (width, width, width, width)
        return ValueParser.parse_box(value, 0)

    def _calculate_width(self, styles: Dict, available_width: float,
                         margin: Tuple, padding: Tuple, border: Tuple) -> float:
        """计算内容宽度"""
        width_val = styles.get("width", "auto")

        if width_val == "auto":
            # 自动宽度 = 可用宽度 - 外边距 - 边框 - 内边距
            auto_width = (available_width - margin[1] - margin[3] -
                         border[1] - border[3] - padding[1] - padding[3])
            return max(0, auto_width)

        # 解析宽度值
        length = ValueParser.parse_length(width_val)
        if length.unit == "%":
            return available_width * length.value / 100
        return length.to_px(self.default_font_size)

    def _calculate_height(self, styles: Dict, available_height: float) -> float:
        """计算内容高度"""
        height_val = styles.get("height", "auto")

        if height_val == "auto":
            return 0  # 由子元素决定

        length = ValueParser.parse_length(height_val)
        if length.unit == "%":
            return available_height * length.value / 100
        return length.to_px(self.default_font_size)

    def _layout_block_children(self, parent: StyleElement, available_width: float, available_height: float):
        """块级布局子元素"""
        current_y = 0
        max_width = 0

        for child in parent.children:
            child_width, child_height = self.layout(child, available_width, available_height, 0, current_y)
            current_y += child_height
            max_width = max(max_width, child_width)

        # 更新父元素高度（如果auto）
        if parent.computed_styles.get("height") == "auto":
            parent.layout_rect = (
                parent.layout_rect[0],
                parent.layout_rect[1],
                parent.layout_rect[2],
                current_y
            )

    def _layout_inline_children(self, parent: StyleElement, available_width: float, available_height: float):
        """行内布局子元素"""
        current_x = 0
        current_y = 0
        line_height = 0

        for child in parent.children:
            child_width, child_height = self.layout(child, available_width, available_height, current_x, current_y)

            if current_x + child_width > available_width and current_x > 0:
                # 换行
                current_x = 0
                current_y += line_height
                line_height = 0
                child_width, child_height = self.layout(child, available_width, available_height, current_x, current_y)

            current_x += child_width
            line_height = max(line_height, child_height)
